<?php
/**
 * Created by PhpStorm.
 * User: jianlinz
 * Date: 2015/7/2
 * Time: 20:45
 */

echo "<H1>BXXH WELCOME!<br>";
echo "<H1>八仙下海欢迎您！<br>";

?>