<?php
/**
 * Created by PhpStorm.
 * User: jianlinz
 * Date: 2015/7/3
 * Time: 11:33
 */

include_once "config.php";
include_once "wechat.class.php";
header("Content-type:text/html;charset=utf-8");



//$wx = new class_mysql_db();

$db_conn = new mysqli(WX_DBHOST, WX_DBUSER, WX_DBPSW, WX_DBNAME, WX_DBPORT);
var_dump($db_conn);

$result = $db_conn->query("SELECT * FROM `bleboundinfo` WHERE 1");
while($row = $result->fetch_array())
{
    var_dump($row);
}

echo "<br> new test one <br>";
$b = mysql_connect(SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT,SAE_MYSQL_USER,SAE_MYSQL_PASS);
var_dump($b);
echo "<br> new test Two <br>";
$c = mysql_select_db("app_smdzjl",$b);
var_dump($c);

//$wx = new aaa;

//$res = $wx->db_AccessTokenInfo_inqury("a1", "12");
//var_dump($res);


//$res = $wx->db_AccessTokenInfo_save("a1", "12", "5", "aadf");
//$res = $wx->db_BleBoundInfo_duplicate("weixinsmdzjl", "gh_9b450bb63282_02414f1001725e2531d65c544d40fefb", "oAjc8uKl-QS9EGIfRGb81kc9fdJE",
//    "gh_9b450bb63282");
//var_dump($res);
/*
$res = $wx->db_boundinfo_delete("nametest1");
echo $res;
//$res = $wx->db_boundinfo_query("weixinsmdzjl1");
var_dump($res);
*/

class aaa{

    public function db_AccessTokenInfo_save($appid, $appsecret, $lasttime, $access_token)
    {
        //建立连接
        $mysqli=new mysqli(DB_HOST, DB_USER, DB_PSW, DB_NAME);
        if (!$mysqli)
        {
            die('Could not connect: ' . mysqli_error($mysqli));
        }
        //先检查是否存在，如果存在，就更新，否则创建
        $result = $mysqli->query("SELECT * FROM `accesstokeninfo` WHERE `appid` = '$appid' AND `appsecret` = '$appsecret'");
        if (($result->num_rows)>0)  {
            $res1=$mysqli->query("UPDATE `accesstokeninfo` SET `lasttime` = $lasttime
              WHERE `appid` = '$appid' AND `appsecret` = '$appsecret'");
            $res2=$mysqli->query("UPDATE `accesstokeninfo` SET `access_token` = $access_token
              WHERE `appid` = '$appid' AND `appsecret` = '$appsecret'");
            $result = $res1 OR $res2;
        }else{
            $result=$mysqli->query("INSERT INTO `accesstokeninfo` (appid, appsecret, lasttime, access_token)
              VALUES ('$appid', '$appsecret', '$lasttime','$access_token')");
        }
        $mysqli->close();
        return $result;
    }

    public function db_AccessTokenInfo_inqury($appid, $appsecret)
    {
        //建立连接
        $mysqli=new mysqli(DB_HOST, DB_USER, DB_PSW, DB_NAME);
        if (!$mysqli)
        {
            die('Could not connect: ' . mysqli_error($mysqli));
        }
        //先检查是否存在，如果存在，就更新，否则创建
        $result = $mysqli->query("SELECT * FROM `accesstokeninfo` WHERE `appid` = '$appid' AND `appsecret` = '$appsecret'");
        if (($result->num_rows)>0)  {
            $result = $result->fetch_array();
        }else{
            $result = "NOTEXIST";
        }
        $mysqli->close();
        return $result;
    }

}

/*
$mysqli=new mysqli($db_host,$db_user,$db_psw,$db_name);

if (!$mysqli)
{
    die('Could not connect: ' . mysqli_error($mysqli));
}

$result=$mysqli->query("INSERT INTO BleBoundInfo (sid, fromUserName, deviceID, openID, deviceType)
VALUES ('123456', 'weixinsmdzjl1', 'gh_9b450bb63282_02414f1001725e2531d65c544d40fefb1','oAjc8uKl-QS9EGIfRGb81kc9fdJE1','gh_9b450bb632821')");
if ($result){
    echo "操作执行成功";
}else {
    echo "操作执行失败";
}


$result = $mysqli->query("SELECT * FROM `bleboundinfo` WHERE fromUserName = 'weixinsmdzjl1'");

while($row = $result->fetch_array())
{
//var_dump($row);
    if ($row['sid'] == 123456)
    {
    echo "sid= ".($row['sid']);
    echo "fromUserName= ".$row['fromUserName'];
    echo "deviceID= ".$row['deviceID'];
    echo "openID= ".$row['openID'];
    echo "deviceType= ".$row['deviceType'];
    }
}
$result->close();
$mysqli->close();

/*
for ($i=0; $i<count($row);$i++)
{
    //print_r($row);
    //var_dump($row);
    /*
    echo "sid= ".$row[$i]['sid'];
    echo "fromUserName= ".$row[$i]['fromUserName'];
    echo "deviceID= ".$row[$i]['deviceID'];
    echo "openID= ".$row[$i]['openID'];
    echo "deviceType= ".$row[$i]['deviceType'];

}*/

/*
$result = $mysqli->prepare("SELECT * FROM 'BleBoundInfo' WHERE fromUserName = 'weixinsmdzjl'");
$result->bind_param('issss', $sid, $fromUserName, $deviceID, $openID, $deviceType);
$result->execute();

$result->();
while ($result->fetch()) {
    echo $sid."<br>";
    echo $fromUserName."<br>";
    echo $deviceID."<br>";
    echo $openID."<br>";
    echo $deviceType."<br>";
}
$result->close();
$mysqli->close();
*/

/*
 * 为了测试环境变量
 *
echo "<br>Server Name = ".php_uname('n');
echo "<br>Server Name = ".php_uname();
echo "<br>REMOTE_ADDRESS = ".$_SERVER['REMOTE_ADDRESS'];
echo "<br>REMOTE_NAME = ".$_SERVER['REMOTE_NAME'];
echo "<br>REMOTE_HOST = ".$_SERVER['REMOTE_HOST'];
echo "<br>SERVER_ADDRESS = ".$_SERVER['SERVER_ADDR'];
$a = $_SERVER['SERVER_NAME'];
echo "<br>SERVER_NAME = ".$_SERVER['SERVER_NAME'];
echo "<br>LOCAL_ADDR = ".$_SERVER['LOCAL_ADDR'];
echo "<br>GetHostByName = " . GetHostByName($_SERVER['SERVER_NAME']);
echo "<br>smdzjl.sinaapp.com HostByName = " . GetHostByName("smdzjl.sinaapp.com");
echo "<br>localhost HostByName = " . GetHostByName("localhost");
echo "<br>get_server_ip = " . get_server_ip();

$a = $_SERVER['REMOTE_ADDRESS'];
$a1 =$_SERVER['REMOTE_NAME'];
$a2 =$_SERVER['REMOTE_HOST'];
$a3 = GetHostByName($_SERVER['SERVER_NAME']);
$a4 = phpinfo('SERVER_ADDR');
$a5 = php_uname('n');
$a6 = php_uname();
$a7 = GetHostByName("smdzjl.sinaapp.com");
$a8 = GetHostByName("localhost");
$a9 = get_server_ip();

//$db_conn = new mysqli(SAE_MYSQL_HOST_M, SAE_MYSQL_USER, SAE_MYSQL_PASS, "app_smdzjl", SAE_MYSQL_PORT);


*/

?>