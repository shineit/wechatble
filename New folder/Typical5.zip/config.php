<?php
/**
 * Created by PhpStorm.
 * User: jianlinz
 * Date: 2015/7/5
 * Time: 9:26
 */

//正式测试公号/服务公号的配置参数
define("WX_TOKEN", "weixin");  //TOKEN，必须和微信绑定的URL使用的TOKEN一致
define("WX_APPID", "wx32f73ab219f56efb");
define("WX_ENCODINGAESKEY", "");   //填写加密用的EncodingAESKey，如接口为明文模式可忽略
define("WX_APPSECRET", "eca20c2a26a5ec5b64a89d15ba92a781");  //填写高级调用功能的app id, 请在微信开发模式后台查询
define("WX_DEBUG", false);
define("WX_LOGCALLBACK", false);

//不同的方式来确定本机运行环境，还是服务器运行环境，本来想获取Localhost来进行判断，但没成功
//实验了不同的方式，包括$_SERVER['LOCAL_ADDR']， $_SERVER['SERVER_ADDR']， getenv('SERVER_ADDR')等方式
//GetHostByName($_SERVER['SERVER_NAME'])只能获取IP地址，也不稳定
//使用php_uname('n') == "CV0002816N4")也算是一个不错的方式，但依然丑陋，需要每个测试者单独配置，
//也可以使用云服务器的名字来反向匹配，因为服务器的名字是唯一的
//
if ((php_uname('n') == "smdzjl") || (php_uname('n') == "SMDZJL"))   //smdzjl.sinaapp.com
{
    define("WX_DBHOST", "localhost");    //连接的服务器地址
    define("WX_DBUSER","TestUser");     //连接数据库的用户名
    define("WX_DBPSW", "123456");        //连接数据库的密码
    define("WX_DBNAME","BXXH");         //连接的数据库名称
}else   //CV0002816N4
{
    define("WX_DBHOST", "localhost");    //连接的服务器地址
    define("WX_DBUSER","TestUser");     //连接数据库的用户名
    define("WX_DBPSW", "123456");        //连接数据库的密码
    define("WX_DBNAME","BXXH");         //连接的数据库名称
}

//测试公号的后台运行配置参数
define("WX_TOOL_SERVICENUM", "gh_9b450bb63282");
define("WX_TOOL_APPID", "wx32f73ab219f56efb");
define("WX_TOOL_APPSECRET", "eca20c2a26a5ec5b64a89d15ba92a781");
define("WX_TOOL_BLEMAC", "D03972A5EF24");


?>
