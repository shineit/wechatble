<?php
/**
 * Created by PhpStorm.
 * User: jianlinz
 * Date: 2015/7/1
 * Time: 19:52
 */

/**Start of tool_main
 * 本工具用于管理员生成设备二维码，并测试扫码和绑定设备功能
 *
 *
 * 工作步骤如下
 * 1、申请测试账号
 * 2、在config.properties中配置公众平台账号相关信息及token
 * 3、服务端部署，在测试号中配置服务url和token
 * 4、公众平台开发介绍，服务端代码介绍，创建自定义菜单
 * 5、修改demo服务器代码灯泡通信协议为设备自定义协议
 * 6、确定设备id，生成二维码；确定设备参数，对设备进行授权
 * 7、和设备联调
 *
**/
include_once "config.php";
include_once "wechat.class.php";
header("Content-type:text/html;charset=utf-8");

//如果运行在本地，以下地址存放二维码图片
static $imagePath = "D:/work/image/";

$a = $_SERVER['REMOTE_ADDRESS'];
$a1 =$_SERVER['REMOTE_NAME'];
$a2 =$_SERVER['REMOTE_HOST'];
$a3 = GetHostByName($_SERVER['SERVER_NAME']);
$a4 = phpinfo('SERVER_ADDR');
$a5 = php_uname('n');
$a6 = php_uname();
$a7 = GetHostByName("smdzjl.sinaapp.com");
$a8 = GetHostByName("localhost");
$a9 = get_server_ip();

//Step1:刷新Token
echo "<br><H2>微信创造硬件工作环境即将开始......<br></H2>";
$wxObj = new class_wx_IOT_sdk(WX_TOOL_APPID, WX_TOOL_APPSECRET);
//实验Token是否已经被刷新
echo "<br>最新刷新的Token=<br>"."$wxObj->access_token"."<br>";

//Step2:创建微信界面上自定义的菜单
static $self_create_menu = '{"button":[{"name":"绑操",
            "sub_button":[{"type":"click","name":"绑定","key":"CLICK_BIND"},
                            {"type":"click","name":"解绑","key":"CLICK_UNBIND"},
                            {"type":"click","name":"查询","key":"CLICK_BAND_INQ"}]},
    {"name":"开关",
            "sub_button":[{"type":"click","name":"开灯","key":"CLICK_LIGHT_ON"},
                            {"type":"click","name":"关灯","key":"CLICK_LIGHT_OFF"},
                            {"type":"click","name":"查询","key":"CLICK_LIGHT_INQ"}]},
    {"name":"测试",
            "sub_button":[{"type":"click","name":"关于","key":"CLICK_ABOUT"},
                            {"type":"click","name":"技术","key":"CLICK_TECH"},
                            {"type":"click","name":"测试","key":"CLICK_TEST"}]}
    ]}';
echo "<br>自定义菜单创建 <br>";
var_dump($wxObj->create_menu($self_create_menu));

//Step3: 使用硬件API创建二维码
//为硬件设备创建二维码，DeviceID自动生成(APPID+随机码组成），也可以自行赋值
//二维码显示在界面上，授权后才能进行扫描绑定
//设备id 由厂商指定，建议由字母、数字、下划线组成，以免json解析失败。
//Step3.1: 使用设备ID和二维码分离的方式创建，一直不成功
// 生成并显示设备ID
//
//$deviceIdBLE= $wxObj->generateDeviceId();
//echo "DeviceID=".$deviceIdBLE."<br>";
//使用API创建设备二维码
//$qrcodetmp = $wxObj->create_qrcodebyDeviceid($deviceIdBLE);
//echo "<br>二维码及Ticket为： <br>".$qrcodetmp."<br>";
//将二维码使用图像方式显示出来
//var_dump($wxObj->createQrcodeDisplan("https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=".$qrcodetmp));
//使用API验证二维码
//echo "<br>二维码验证的结果<br>";
//var_dump($wxObj->verify_qrcode($qrcodetmp));
//
//Step3.2: 使用DeviceId + QrCod一起创建的方式
$qrcode_result = $wxObj->create_DeviceidAndQrcode();
var_dump($qrcode_result);
$deviceIdBLE = $qrcode_result["deviceid"];
$qrcodeBLE = $qrcode_result["qrticket"];
//验证二维码
$qrcode_result = $wxObj->verify_qrcode($qrcodeBLE);
echo "<br>二维码验证的结果<br>";
var_dump($qrcode_result);
$deviceTypeBLE = $qrcode_result["device_type"];
//将二维码使用图像方式显示出来
var_dump($wxObj->create_qrcodeDisplay($qrcodeBLE));

// Step4 设备授权
// 设备授权后才能进行扫码绑定
// 开发调试时，可以先用假的信息授权，测试服务端设备绑定事件的处理。
// 设备参数确定后，更新为正确的设备属性，再和设备联调。
echo "<br>设备授权结果 <br>";
var_dump($wxObj->device_AuthBLE($deviceIdBLE, WX_TOOL_BLEMAC));

// Step5 用户扫码，或者强制用户绑定

// Step6 设备状态查询
echo "<br>查询设备状态 <br>";
var_dump($wxObj->getstat_qrcodebyDeviceid($deviceIdBLE));

//end of tool_main();


function get_server_ip() {
    if (isset($_SERVER)) {
        if($_SERVER['SERVER_ADDR']) {
            $server_ip = $_SERVER['SERVER_ADDR'];
        } else {
            $server_ip = $_SERVER['LOCAL_ADDR'];
        }
    } else {
        $server_ip = getenv('SERVER_ADDR');
    }
    return $server_ip;
}

?>